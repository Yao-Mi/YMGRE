#ifndef YMGRE_RASTERIZATION_H
#define YMGRE_RASTERIZATION_H
#include "../OPOBJ/YMGRE_OBJ.h"
#include "YMGRE_List.h"

//基础直线光栅化，不包含窗口裁剪
void YMGRE_Img_SetBrushColor(GRErgb24 color);
void YMGRE_Img_Line(GRE_FrameBuffer data, uint16 width, uint16 height, int16 x1, int16 y1, int16 x2, int16 y2);
void YMGRE_Img_LineDepth(GRE_FrameBuffer data, float32* zbuff, uint16 width, uint16 height,
	int16 x1, int16 y1, float32 z1, int16 x2, int16 y2, float32 z2, GRErgb24 color, uint8 depthTest);
// Projected triangle depth: 1/z = plane.x*x + plane.y*y + plane.w.
uint8 YMGRE_Triangle_DepthPlane(GRE_Vertex4d points, GRE_Polygon4d polygon, GRE_Fvector4d plane);
// Mesh edge using its face depth at each raster sample; endpoints must be in bounds.
// Uses the current brush and retains foreground depth testing.
void YMGRE_Img_LineDepthPlane(GRE_FrameBuffer data, uint16 width, float32* zbuff,
	GRE_Fvector4d plane, int16 x1, int16 y1, int16 x2, int16 y2);
//多边形扫描线填充，输入边必须已经位于图像范围内
// 2D 接口：plane 为 A*x+B*y+C*z+D=0；3D 多边形入口内部另做透视深度校正。
void YMGRE_Img_Scanline_AreaFill(GRE_FrameBuffer data, uint16 width, uint16 height, GRE_LinesList ring,
	GRE_Fvector4d plane, float32* zbuff, GRErgb24 fillColor);

//图元光栅化
void YMGRE_PolygonObject_Primitive_Rasterization(GRE_Object4d myobj, GRE_Camera4d mycam, uint8 showLines);
void YMGRE_PolygonObject_Primitive_RasterizationTo(GRE_Object4d myobj, GRE_Vertex4d points, uint8* polygonHide,
	GRErgb24* polygonColor, GRE_Camera4d mycam, uint8 showLines);//使用外部相机工作区绘制多边形
//三角图元光栅化
void YMGRE_TrangleObject_Primitive_Rasterization(GRE_Object4d myTrangleObj, GRE_Material mymaterial, GRE_Camera4d mycam);
void YMGRE_TrangleObject_Primitive_RasterizationTo(GRE_Object4d myTrangleObj, GRE_Vertex4d points, uint8* polygonHide,
	GRErgb24* polygonColor, GRE_Material mymaterial, GRE_Camera4d mycam);//使用外部相机工作区绘制三角形
void YMGRE_TrangleObject_Primitive_Rasterization_wN(GRE_Object4d object, GRE_Vertex4d_wN points,
	uint8* polygonHide, GRE_Material material, GRE_List lights, gre_fvector4d* lightPos,
	GRE_FMat4x4 worldToCamera, GRE_Camera4d camera);
void YMGRE_TrangleObject_Primitive_Rasterization_VertexColor_wN(GRE_Object4d object,
	GRE_Vertex4d_wN points,uint8* polygonHide,GRE_Camera4d camera);

//三角图元线框模型绘制
void YMGRE_TrangleObject_Wires(GRE_Object4d myTrangleObj, GRE_Camera4d mycam);
void YMGRE_TrangleObject_WiresTo(GRE_Object4d myTrangleObj, GRE_Vertex4d points, uint8* polygonHide, GRE_Camera4d mycam);//使用外部相机工作区绘制线框
void YMGRE_TrangleObject_Wires_wN(GRE_Object4d object, GRE_Vertex4d_wN points,
	uint8* polygonHide, GRE_Camera4d camera);

//灯光光栅化绘制
void YMGRE_Light_Primitive_Rasterization(GRE_Light4d mylight, GRE_Camera4d mycam, uint8 showLightSize);


#endif // !YMGRE_RASTERIZATION_H

